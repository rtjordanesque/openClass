// ------------------------------------------------------------
// *************************Activité 1************************
// ------------------------------------------------------------

// Liste des liens Web à afficher. Un lien est défini par :
// - son titre
// - son URL
// - son auteur (la personne qui l'a publié)
var listeLiens = [
    {
        titre: "So Foot",
        url: "http://sofoot.com",
        auteur: "yann.usaille"
    },
    {
        titre: "Guide d'autodéfense numérique",
        url: "http://guide.boum.org",
        auteur: "paulochon"
    },
    {
        titre: "L'encyclopédie en ligne Wikipedia",
        url: "http://Wikipedia.org",
        auteur: "annie.zette"
    }
];

//fonction affiche des liens
function affichageLien(lien){
    var lienElem=document.createElement("div");
    lienElem.setAttribute("class","lien");

    //Lien de redirection
    var lienRedirection=document.createElement("a");
    lienRedirection.textContent=lien.titre;
    lienRedirection.href=lien.url;
    lienRedirection.style.color="#428bca";
    lienRedirection.style.fontWeight="800";
    lienRedirection.style.textDecoration="none";

    //Titre du lien
    var lienTitre=document.createElement("p");
    lienTitre.style.marginBottom=0;

    //Url du lien
    var lienUrl=document.createElement("span");
    lienUrl.textContent=lien.url;
    lienUrl.style.marginLeft="5px";

    //auteur du lien
    var lienAuteur=document.createElement("span");
    lienAuteur.innerHTML="Ajouté par "+lien.auteur;

    //insertion dans le dom
    lienTitre.appendChild(lienRedirection);
    lienElem.appendChild(lienTitre);
    lienTitre.insertAdjacentElement("beforeend",lienUrl);
    lienElem.appendChild(lienAuteur);
    return lienElem;
}

//---code commenté de l'activité 1 pour ne plus afficher la liste dans l'activité 3
//boucle pour chacun des liens création d'une div avec la class="lien"
// for(lien of listeLiens){
//     var lienElem=affichageLien(lien);
//     document.getElementById("contenu").appendChild(lienElem);
// }


// ------------------------------------------------------------
// *************************Activité 2************************
// ------------------------------------------------------------

//Fonction création champs formulaire
function creerInput(nomInput,placeholderText){
var elem=document.createElement("input");
elem.placeholder = placeholderText;
elem.type="text";
elem.name=nomInput;
elem.style.margin="0 15px 15px 0";
elem.required="required";
return elem;
}

//Fonction de vérification url lien
function verifUrl(url){
    var verif1=/http:\/\//;
    var verif2=/https:\/\//;
    if((!verif1.test(url))&&(!verif2.test(url))){
        url="http://"+url;
    }
    return url;
}

//Fonction d'affichage message lien ajouté
function affichageMessage(titre){
    var message=document.createElement("div");
    message.textContent="Le lien "+titre+" a bien été ajouté";
    message.style.backgroundColor="#d6ecf6";
    message.style.padding="20px";
    message.style.marginBottom="15px"
    message.style.fontSize="18px";
    document.body.insertBefore(message,document.querySelector("button"));
    setTimeout(function () {
        message.style.display= "none";
        }, 2000);
}

//Création bouton d'ajout de lien pour afficher le formulaire
var ajouterLien=document.createElement("button");
ajouterLien.textContent="Ajouter un lien";
ajouterLien.style.marginBottom="15px";
document.body.insertBefore(ajouterLien,document.getElementById("contenu"));

//Création formulaire ajout
var form=document.createElement("form");
form.style.display="none";

//Champ ajout nom auteur
var nomAjoute=creerInput("nomAjoute","Entrez votre nom");

//Champ ajout titre lien
var titreAjoute=creerInput("titreAjoute","Entrez le titre du lien");
titreAjoute.style.width="250px";

//Champ ajout url lien
var urlAjoute=creerInput("urlAjoute","Entrez l'URL du lien");
urlAjoute.style.width="350px";

//Bouton validation formulaire
var ajouter=document.createElement("input");
ajouter.value="Ajouter";
ajouter.type="submit";

//Insertion formulaire
form.appendChild(nomAjoute);
form.appendChild(titreAjoute);
form.appendChild(urlAjoute);
form.appendChild(ajouter);
document.body.insertBefore(form,document.getElementById("contenu"));

//Evenement clic bouton "ajouter lien" pour afficher formulaire
ajouterLien.addEventListener("click",function(e){
    nomAjoute.value="";
    titreAjoute.value="";
    urlAjoute.value="";
    ajouterLien.style.display="none";
    form.style.display="block";
});


// ------------------------------------------------------------
// *************************Activité 3************************
// ------------------------------------------------------------


// ------------------Fonctions générique AJAX------------
function ajaxGet(url, callback) {
    // Prend en paramètres l'URL cible et la fonction callback appelée en cas de succès
    var req = new XMLHttpRequest();
    req.open("GET", url);
    req.addEventListener("load", function () {
        if (req.status >= 200 && req.status < 400) {
            // Appelle la fonction callback en lui passant la réponse de la requête
            callback(req.responseText);
        } else {
            console.error(req.status + " " + req.statusText + " " + url);
        }
    });
    req.addEventListener("error", function () {
        console.error("Erreur réseau avec l'URL " + url);
    });
    req.send(null);
}

function ajaxPost(url, data, callback, isJson) {
    // Paramètres : URL cible, la donnée à envoyer, fonction callback et si données JSON
    var req = new XMLHttpRequest();
    req.open("POST", url);
    req.addEventListener("load", function () {
        if (req.status >= 200 && req.status < 400) {
            // Appelle la fonction callback en lui passant la réponse de la requête
            callback(req.responseText);
        } else {
            console.error(req.status + " " + req.statusText + " " + url);
        }
    });
    req.addEventListener("error", function () {
        console.error("Erreur réseau avec l'URL " + url);
    });
    if (isJson) {
        // Définit le contenu de la requête comme étant du JSON
        req.setRequestHeader("Content-Type", "application/json");
        // Transforme la donnée du format JSON vers le format texte avant l'envoi
        data = JSON.stringify(data);
    }
    req.send(data);
}
// --------------------fin fonctions génériques AJAX------------


// Récupération des données JSON depuis le serveur grâce à ma méthode "ajaxGet"
ajaxGet("https://oc-jswebsrv.herokuapp.com/api/liens", function (reponse) {
    // Transforme la réponse en tableau d'objets JavaScript
    var liensServeur = JSON.parse(reponse);
    // Affichage des liens grâce à la méthode crée en acivité 1
    liensServeur.forEach(function (lien) {
        var lienServeurElt=affichageLien(lien);
        document.getElementById("contenu").appendChild(lienServeurElt);
    })
});

//Evenement enregistrement données
form.addEventListener("submit",function(e){
    var nom=form.elements.nomAjoute.value;
    var titre=form.elements.titreAjoute.value;
    var url=verifUrl(form.elements.urlAjoute.value);
    //création objet
    var nouveauLien={
        titre:titre,
        url:url,
        auteur:nom
    }
    // Envoi de l'objet au serveur avec la méthode "ajaxPost"
    ajaxPost("https://oc-jswebsrv.herokuapp.com/api/lien", nouveauLien,
        function (reponse) {
            // Le film est affiché dans la console en cas de succès
            console.log("Le lien " + JSON.stringify(nouveauLien) + " a été envoyé au serveur");
            //affichage nouveau lien
            var nouveauLienElem=affichageLien(nouveauLien);
            document.getElementById("contenu").insertAdjacentElement("afterbegin",nouveauLienElem);
            //affichage du message d'ajout
            affichageMessage(titre);
            form.style.display="none";
            ajouterLien.style.display="block";
        },
        true // Valeur du paramètre isJson
    );
    e.preventDefault(); // Annulation de l'envoi des données
});


